/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class QuickChat {

 

    private final Scanner input;

    // Five arrays required for Part 3
    private Message[] sentMessages = new Message[0];
    private Message[] disregardedMessages = new Message[0];
    private Message[] storedMessages = new Message[0];

    private String[] messageHashes = new String[0];
    private String[] messageIDs = new String[0];

    private int messagesCreated = 0;
    private int numberOfMessages = 0;

    private final String JSON_FILE = "messages.json";

    // Constructor
    public QuickChat(Scanner input) {
        this.input = input;
    }

    // Start the application
    public void start() {

 

    System.out.println("\n================================");
    System.out.println("        WELCOME TO QUICKCHAT");
    System.out.println("================================");

    // Load previously stored messages without deleting the file
    loadStoredMessages();

    System.out.print("How many messages would you like to enter? ");

    numberOfMessages = readInteger();

    while (true) {

        System.out.println("\n========== MAIN MENU ==========");
        System.out.println("1) Send Messages");
        System.out.println("2) Show recently sent messages");
        System.out.println("3) Stored Messages");
        System.out.println("4) Quit");

        System.out.print("Enter your choice: ");

        int choice = readInteger();

        switch (choice) {

            case 1 -> sendMessages();

            case 2 -> displaySentMessages();

            case 3 -> storedMessagesMenu();

            case 4 -> {
                System.out.println("\nTotal messages sent: "
                        + sentMessages.length);

                System.out.println("Goodbye!");
                return;
            }

            default ->
                System.out.println("Invalid choice. Please try again.");
        }
    }
}

    // Read an integer safely
    private int readInteger() {

        while (!input.hasNextInt()) {

            System.out.print("Please enter a valid number: ");
            input.nextLine();
        }

        int number = input.nextInt();
        input.nextLine();

        return number;
    }

    // Send messages
    private void sendMessages() {

        if (numberOfMessages <= 0) {
            System.out.println("You have not selected any messages.");
            return;
        }

        while (messagesCreated < numberOfMessages) {

            System.out.println("\n========== NEW MESSAGE ==========");

            System.out.print("Enter recipient cellphone number: ");
            String recipient = input.nextLine();

            System.out.print("Enter your message: ");
            String text = input.nextLine();

           Message message = new Message(
        messagesCreated,
        recipient,
        text,
        "User"
           );
           

            if (!message.isRecipientValid()) {
                System.out.println(message.checkRecipientCell());
                continue;
            }

            if (text.trim().isEmpty()) {
                System.out.println("Message cannot be empty.");
                continue;
            }

            if (text.length() > 250) {
                System.out.println(message.checkMessageLength());
                continue;
            }

            System.out.println(message.checkMessageLength());

            System.out.println("\n" + message.printMessages());

            System.out.println("\nChoose an action:");
            System.out.println("1) Send Message");
            System.out.println("2) Disregard Message");
            System.out.println("3) Store Message to send later");

            System.out.print("Enter your choice: ");

            int action = readInteger();

            if (action < 1 || action > 3) {
                System.out.println("Invalid option. Message not processed.");
                continue;
            }

            String result = message.SentMessage(action);

            System.out.println(result);

            // Record the message ID and hash
            addMessageID(message.getMessageID());
            addMessageHash(message.getMessageHash());

            // Add the message to the correct array
            switch (action) {

                case 1 -> {
                    sentMessages = addMessage(sentMessages, message);
                    messagesCreated++;
                }

                case 2 -> {
                    disregardedMessages =
                            addMessage(disregardedMessages, message);

                    System.out.println("Message disregarded.");
                    messagesCreated++;
                }

                case 3 -> {
                    if (result.startsWith("Message successfully stored.")) {

                        storedMessages =
                                addMessage(storedMessages, message);

                        messagesCreated++;

                    } else {

                        System.out.println("Message was not stored.");
                    }
                }

                default -> {
                }
            }

            if (messagesCreated >= numberOfMessages) {
                System.out.println("\nYou have reached your selected message limit.");
            }
        }
    }

    // Add a message dynamically to an array
    private Message[] addMessage(Message[] oldArray, Message message) {

        Message[] newArray = new Message[oldArray.length + 1];

        System.arraycopy(oldArray, 0, newArray, 0, oldArray.length);

        newArray[oldArray.length] = message;

        return newArray;
    }

    // Add message ID dynamically
    private void addMessageID(String id) {

        String[] newArray = new String[messageIDs.length + 1];

        System.arraycopy(messageIDs, 0, newArray, 0, messageIDs.length);

        newArray[messageIDs.length] = id;

        messageIDs = newArray;
    }

    // Add message hash dynamically
    private void addMessageHash(String hash) {

        String[] newArray = new String[messageHashes.length + 1];

        System.arraycopy(messageHashes, 0, newArray, 0, messageHashes.length);

        newArray[messageHashes.length] = hash;

        messageHashes = newArray;
    }

    // Display recently sent messages
    private void displaySentMessages() {

        System.out.println("\n========== SENT MESSAGES ==========");

        if (sentMessages.length == 0) {
            System.out.println("There are no sent messages.");
            return;
        }

        for (Message message : sentMessages) {
            System.out.println(message.printMessages());
            System.out.println("--------------------------------");
        }
    }

    // Stored Messages submenu
    private void storedMessagesMenu() {

        while (true) {

            System.out.println("\n========== STORED MESSAGES ==========");
            System.out.println("1) Display sender and recipient of stored messages");
            System.out.println("2) Display the longest stored message");
            System.out.println("3) Search for a message using its ID");
            System.out.println("4) Search for messages by recipient");
            System.out.println("5) Delete a message using its hash");
            System.out.println("6) Display complete stored messages report");
            System.out.println("7) Return to main menu");

            System.out.print("Enter your choice: ");

            int choice = readInteger();

            switch (choice) {

                case 1 -> displayStoredSendersAndRecipients();

                case 2 -> displayLongestMessage();

                case 3 -> searchByMessageID();

                case 4 -> searchByRecipient();

                case 5 -> deleteMessageByHash();

                case 6 -> displayStoredMessagesReport();

                case 7 -> {
                    return;
                }

                default -> System.out.println("Invalid option.");
            }
        }
    }

    // 1. Display sender and recipient
    private void displayStoredSendersAndRecipients() {

        System.out.println("\n========== SENDERS AND RECIPIENTS ==========");

        if (storedMessages.length == 0) {
            System.out.println("No stored messages found.");
            return;
        }

        for (Message message : storedMessages) {

            System.out.println("Sender: " + message.getSender());
            System.out.println("Recipient: " + message.getRecipient());
            System.out.println("--------------------------------");
        }
    }

    // 2. Display longest stored message
    private void displayLongestMessage() {

        System.out.println("\n========== LONGEST MESSAGE ==========");

        if (storedMessages.length == 0) {
            System.out.println("No stored messages found.");
            return;
        }

        Message longest = storedMessages[0];

        for (Message message : storedMessages) {

            if (message.getMessageText().length()
                    > longest.getMessageText().length()) {

                longest = message;
            }
        }

        System.out.println(longest.getMessageText());
    }

    // 3. Search using message ID
    private void searchByMessageID() {

        System.out.print("\nEnter message ID: ");

        String searchID = input.nextLine();

        for (Message message : storedMessages) {

            if (message.getMessageID().equals(searchID)) {

                System.out.println("\nMessage found!");
                System.out.println("Recipient: " + message.getRecipient());
                System.out.println("Message: " + message.getMessageText());

                return;
            }
        }

        System.out.println("Message ID not found.");
    }

    // 4. Search messages by recipient
    private void searchByRecipient() {

        System.out.print("\nEnter recipient cellphone number: ");

        String searchRecipient = input.nextLine();

        boolean found = false;

        System.out.println("\n========== SEARCH RESULTS ==========");

        for (Message message : storedMessages) {

            if (message.getRecipient().equalsIgnoreCase(searchRecipient)) {

                System.out.println("Message: " + message.getMessageText());

                found = true;
            }
        }

        if (!found) {
            System.out.println("No messages found for this recipient.");
        }
    }

    // 5. Delete message using hash
    private void deleteMessageByHash() {

        System.out.print("\nEnter the message hash to delete: ");

        String searchHash = input.nextLine();

        int foundIndex = -1;

        for (int i = 0; i < storedMessages.length; i++) {

            if (storedMessages[i].getMessageHash()
                    .equalsIgnoreCase(searchHash)) {

                foundIndex = i;
                break;
            }
        }

        if (foundIndex == -1) {
            System.out.println("Message hash not found.");
            return;
        }

        Message[] newArray =
                new Message[storedMessages.length - 1];

        int newIndex = 0;

        for (int i = 0; i < storedMessages.length; i++) {

            if (i != foundIndex) {
                newArray[newIndex] = storedMessages[i];
                newIndex++;
            }
        }

        storedMessages = newArray;

        saveStoredMessages();

        System.out.println("Message successfully deleted.");
    }

    // 6. Display full report
    private void displayStoredMessagesReport() {

        System.out.println("\n========== STORED MESSAGES REPORT ==========");

        if (storedMessages.length == 0) {
            System.out.println("No stored messages found.");
            return;
        }

        for (Message message : storedMessages) {

            System.out.println("Message ID: " + message.getMessageID());
            System.out.println("Message Hash: " + message.getMessageHash());
            System.out.println("Sender: " + message.getSender());
            System.out.println("Recipient: " + message.getRecipient());
            System.out.println("Message: " + message.getMessageText());
            System.out.println("Status: " + message.getMessageStatus());

            System.out.println("--------------------------------------");
        }
    }

    // Load stored messages from JSON file
    private void loadStoredMessages() {

        File file = new File(JSON_FILE);

        if (!file.exists()) {
            System.out.println("No previous stored messages found.");
            return;
        }

        try (BufferedReader reader =
                     new BufferedReader(new FileReader(file))) {

            String line;

            while ((line = reader.readLine()) != null) {

                if (line.trim().isEmpty()) {
                    continue;
                }

                Map<String, String> data = parseJsonObject(line);

                String id = data.get("messageID");
                String sender = data.get("sender");
                String recipient = data.get("recipient");
                String messageText = data.get("message");
                String number = data.get("messageNumber");
                String status = data.get("status");

                if (id == null || recipient == null
                        || messageText == null || number == null) {

                    System.out.println("A stored record was skipped because information is missing.");
                    continue;
                }

                int messageNumber = Integer.parseInt(number);

                Message message = new Message(
                        messageNumber,
                        sender == null ? "User" : sender,
                        recipient,
                        messageText,
                        id
                );

                message.setMessageStatus(
                        status == null ? "Stored" : status
                );

                storedMessages = addMessage(storedMessages, message);

                addMessageID(message.getMessageID());
                addMessageHash(message.getMessageHash());
            }

            System.out.println("Stored messages loaded: "
                    + storedMessages.length);

        } catch (IOException | NumberFormatException e) {

            System.out.println("Error reading stored messages: "
                    + e.getMessage());
        }
    }

    // Parse one JSON object
    private Map<String, String> parseJsonObject(String json) {

        Map<String, String> data = new LinkedHashMap<>();

        int index = 0;

        while (index < json.length()) {

            while (index < json.length()
                    && (Character.isWhitespace(json.charAt(index))
                    || json.charAt(index) == '{'
                    || json.charAt(index) == ','
                    || json.charAt(index) == '}')) {

                index++;
            }

            if (index >= json.length()) {
                break;
            }

            if (json.charAt(index) != '"') {
                break;
            }

            StringResult keyResult = readJsonString(json, index);

            String key = keyResult.value;
            index = keyResult.nextIndex;

            while (index < json.length()
                    && (Character.isWhitespace(json.charAt(index))
                    || json.charAt(index) == ':')) {

                index++;
            }

            if (index >= json.length()) {
                break;
            }

            String value;

            if (json.charAt(index) == '"') {

                StringResult valueResult = readJsonString(json, index);

                value = valueResult.value;
                index = valueResult.nextIndex;

            } else {

                int start = index;

                while (index < json.length()
                        && json.charAt(index) != ','
                        && json.charAt(index) != '}') {

                    index++;
                }

                value = json.substring(start, index).trim();
            }

            data.put(key, value);
        }

        return data;
    }

    // Read a JSON string and decode escaped characters
    private StringResult readJsonString(String json, int start) {

        StringBuilder value = new StringBuilder();

        int index = start + 1;

        while (index < json.length()) {

            char current = json.charAt(index);

            if (current == '"') {

                return new StringResult(value.toString(), index + 1);
            }

            if (current == '\\' && index + 1 < json.length()) {

                index++;

                char escaped = json.charAt(index);

                switch (escaped) {

                    case '"' -> value.append('"');

                    case '\\' -> value.append('\\');

                    case '/' -> value.append('/');

                    case 'n' -> value.append('\n');

                    case 'r' -> value.append('\r');

                    case 't' -> value.append('\t');

                    case 'b' -> value.append('\b');

                    case 'f' -> value.append('\f');

                    case 'u' -> {
                        if (index + 4 < json.length()) {

                            String hex = json.substring(index + 1, index + 5);

                            value.append((char) Integer.parseInt(hex, 16));

                            index += 4;
                        }
                    }

                    default -> value.append(escaped);
                }

            } else {

                value.append(current);
            }

            index++;
        }

        return new StringResult(value.toString(), index);
    }

    // Helper class for JSON string reading
    private static class StringResult {

        String value;
        int nextIndex;

        StringResult(String value, int nextIndex) {

            this.value = value;
            this.nextIndex = nextIndex;
        }
    }

    // Escape text when writing JSON
    private String escapeJson(String value) {

        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    // Rewrite JSON file after deletion
    private void saveStoredMessages() {

        try (FileWriter writer = new FileWriter(JSON_FILE, false)) {

            for (Message message : storedMessages) {

                writer.write("{"
                        + "\"messageID\":\"" + escapeJson(message.getMessageID()) + "\","
                        + "\"messageHash\":\"" + escapeJson(message.getMessageHash()) + "\","
                        + "\"messageNumber\":" + message.getMessageNumber() + ","
                        + "\"sender\":\"" + escapeJson(message.getSender()) + "\","
                        + "\"recipient\":\"" + escapeJson(message.getRecipient()) + "\","
                        + "\"message\":\"" + escapeJson(message.getMessageText()) + "\","
                        + "\"status\":\"Stored\""
                        + "}\n");
            }

        } catch (IOException e) {

            System.out.println("Could not update JSON file: " + e.getMessage());
        }
    }
}  

