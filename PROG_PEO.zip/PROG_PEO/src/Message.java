
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */

import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;

public class Message {

    private final String messageID;
    private final int messageNumber;
    private final String sender;
    private final String recipient;
    private final String messageText;

    private String messageStatus;

    private static int totalMessagesSent = 0;

    // Original constructor for existing tests
    public Message(int messageNumber, String recipient,
                   String messageText) {

        this(messageNumber, "User", recipient, messageText, null);
    }

    // Constructor used by QuickChat
    // Order: message number, sender, recipient, message text
    // Constructor: message number, recipient, message text, sender
public Message(int messageNumber, String recipient,
               String messageText, String sender) {

    this(messageNumber, sender, recipient, messageText, null);
}

    // Constructor for restoring messages from JSON
    public Message(int messageNumber, String sender,
                   String recipient, String messageText,
                   String existingMessageID) {

        this.messageNumber = messageNumber;
        this.sender = sender;
        this.recipient = recipient == null ? null : recipient.trim();
        this.messageText = messageText;

        if (existingMessageID == null || existingMessageID.isEmpty()) {
            this.messageID = generateMessageID();
        } else {
            this.messageID = existingMessageID;
        }

        this.messageStatus = "Pending";
    }

    // Generate a random 10-digit message ID
    private String generateMessageID() {

        Random random = new Random();

        long number = 1000000000L
                + (long) (random.nextDouble() * 9000000000L);

        return String.valueOf(number);
    }

    // Check message ID length
    public boolean checkMessageID() {

        return messageID != null && messageID.length() <= 10;
    }

    // Check recipient cellphone number
    public String checkRecipientCell() {

        if (isRecipientValid()) {
            return "Cell phone number successfully captured.";
        }

        return "Cell phone number is incorrectly formatted or does not contain an international code. Please correct the number and try again.";
    }

    // Validate South African international cellphone number
    public boolean isRecipientValid() {
        

    if (recipient == null) {
        return false;
    }

    String number = recipient.trim();

    // Accept South African international format
    boolean internationalFormat =
            number.matches("^\\+27[0-9]{9}$");

    // Accept South African local format
    boolean localFormat =
            number.matches("^0[0-9]{9}$");

    return internationalFormat || localFormat;
}


    // Check message length
    public String checkMessageLength() {

        if (messageText != null && messageText.length() <= 250) {
            return "Message ready to send.";
        }

        int excess = messageText == null
                ? 250 : messageText.length() - 250;

        return "Message exceeds 250 characters by "
                + excess + "; please reduce the size.";
    }

    // Create message hash
    public String createMessageHash() {

        if (messageText == null || messageText.trim().isEmpty()) {
            return (messageID.substring(0, 2) + ":"
                    + messageNumber + ":EMPTY").toUpperCase();
        }

        String[] words = messageText.trim().split("\\s+");

        String firstWord = words[0]
                .replaceAll("[^A-Za-z0-9]", "");

        String lastWord = words[words.length - 1]
                .replaceAll("[^A-Za-z0-9]", "");

        String firstTwoDigits = messageID.substring(0, 2);

        return (firstTwoDigits + ":" + messageNumber + ":"
                + firstWord + lastWord).toUpperCase();
    }

    // Choose whether to send, disregard or store a message
    public String SentMessage(int option) {

        switch (option) {

            case 1 -> {
                messageStatus = "Sent";
                totalMessagesSent++;
                return "Message successfully sent.";
            }

            case 2 -> {
                messageStatus = "Disregarded";
                return "Press 0 to delete the message.";
            }

            case 3 -> {
                return storeMessage();
            }

            default -> {
                return "Invalid option.";
            }
        }
    }

    // Escape special characters for JSON
    private String escapeJson(String value) {

        if (value == null) {
            return "";
        }

        return value.replace("\\", "\\\\")
                .replace("\"", "\\\"")
                .replace("\n", "\\n")
                .replace("\r", "\\r")
                .replace("\t", "\\t");
    }

    // Store message in messages.json
    public String storeMessage() {

        messageStatus = "Stored";

        try (FileWriter writer =
                     new FileWriter("messages.json", true)) {

            writer.write("{"
                    + "\"messageID\":\"" + escapeJson(messageID) + "\","
                    + "\"messageHash\":\"" + escapeJson(createMessageHash()) + "\","
                    + "\"messageNumber\":" + messageNumber + ","
                    + "\"sender\":\"" + escapeJson(sender) + "\","
                    + "\"recipient\":\"" + escapeJson(recipient) + "\","
                    + "\"message\":\"" + escapeJson(messageText) + "\","
                    + "\"status\":\"" + escapeJson(messageStatus) + "\""
                    + "}\n");

            return "Message successfully stored.";

        } catch (IOException e) {

            return "Error storing message: " + e.getMessage();
        }
    }

    // Display message details
    public String printMessages() {

        return "Message ID: " + messageID
                + "\nMessage Hash: " + createMessageHash()
                + "\nRecipient: " + recipient
                + "\nMessage: " + messageText;
    }

    // Return total messages sent
    public int returnTotalMessagess() {

        return totalMessagesSent;
    }

    // Alternative method name
    public int returnTotalMessages() {

        return totalMessagesSent;
    }

    // Getters
    public String getMessageID() {
        return messageID;
    }

    public String getMessageHash() {
        return createMessageHash();
    }

    public String getSender() {
        return sender;
    }

    public String getRecipient() {
        return recipient;
    }

    public String getMessageText() {
        return messageText;
    }

    public int getMessageNumber() {
        return messageNumber;
    }

    public String getMessageStatus() {
        return messageStatus;
    }

    // Restore message status when loading from JSON
    public void setMessageStatus(String messageStatus) {
        this.messageStatus = messageStatus;
    }
}
