/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Student
 */
import java.io.IOException;
import javax.swing.JOptionPane;
import java.util.Scanner;

public class Main {

    private static String loginMessage;
  

    public static void main(String[] args) {

        try (Scanner input = new Scanner(System.in)) {

            System.out.println("================================");
            System.out.println("       QUICKCHAT SYSTEM");
            System.out.println("================================");

            System.out.println("\nREGISTRATION");

            System.out.print("Enter your username: ");
            String username = input.nextLine();

            System.out.print("Enter your password: ");
            String password = input.nextLine();

            System.out.print("Enter your South African cellphone number: ");
            String cellPhoneNumber = input.nextLine().trim();

            Login user = new Login(username, password, cellPhoneNumber);

            System.out.println("\n" + user.registerUser());

            if (user.checkUserName()
                    && user.checkPasswordComplexity()
                    && user.checkCellPhoneNumber()) {

                System.out.print("\nEnter your first name: ");
                String firstName = input.nextLine();

                System.out.print("Enter your last name: ");
                String lastName = input.nextLine();

                System.out.println("\nLOGIN");

                System.out.print("Enter your username: ");
                String enteredUsername = input.nextLine();

                System.out.print("Enter your password: ");
                String enteredPassword = input.nextLine();

                boolean loginSuccessful =
                        user.loginUser(enteredUsername, enteredPassword);

                String loginMessage = user.returnLoginStatus(
                        loginSuccessful, firstName, lastName);

                System.out.println("\n" + loginMessage);

                if (loginSuccessful) {

                    System.out.println("\nOpening QuickChat...");

                    QuickChat quickChat = new QuickChat(input);
                    quickChat.start();

                } else {

                    System.out.println("Login failed. Application closed.");
                }

            } else {

                System.out.println(
                        "\nRegistration unsuccessful. Please restart the application.");
            }

            System.out.println("\nThank you for using QuickChat.");
        }
    }
}

    